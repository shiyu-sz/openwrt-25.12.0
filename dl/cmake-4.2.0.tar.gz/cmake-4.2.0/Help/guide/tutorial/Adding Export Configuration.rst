Step 11: Adding Export Configuration
====================================

This page was once part of an older version of the CMake tutorial which
last appeared in CMake 4.1.  See the current tutorial version :guide:`here <CMake Tutorial>`.

.. only:: cmakeorg

  To see the older version, follow `this link <https://cmake.org/cmake/help/v4.1/guide/tutorial/Adding%20Export%20Configuration.html>`_
  or select the drop-down in the page header.
